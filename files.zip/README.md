# FB 8 Calendar

Live iCal feed for FB 8 matches, scraped from DBU.

## Deploy to Vercel

1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → New Project → Import your repo
3. Click Deploy (no config needed)
4. Your calendar URL will be: `https://your-project.vercel.app/`

## Subscribe in your calendar app

- **Apple Calendar:** File → New Calendar Subscription → paste URL
- **Google Calendar:** Other calendars → + → From URL → paste URL

Google refreshes every ~24h. Apple can be set to refresh hourly.
